 /* Copyright 2010-2022 NVIDIA CORPORATION & AFFILIATES.  All rights reserved. 
  * 
  * NOTICE TO LICENSEE: 
  * 
  * The source code and/or documentation ("Licensed Deliverables") are 
  * subject to NVIDIA intellectual property rights under U.S. and 
  * international Copyright laws. 
  * 
  * The Licensed Deliverables contained herein are PROPRIETARY and 
  * CONFIDENTIAL to NVIDIA and are being provided under the terms and 
  * conditions of a form of NVIDIA software license agreement by and 
  * between NVIDIA and Licensee ("License Agreement") or electronically 
  * accepted by Licensee.  Notwithstanding any terms or conditions to 
  * the contrary in the License Agreement, reproduction or disclosure 
  * of the Licensed Deliverables to any third party without the express 
  * written consent of NVIDIA is prohibited. 
  * 
  * NOTWITHSTANDING ANY TERMS OR CONDITIONS TO THE CONTRARY IN THE 
  * LICENSE AGREEMENT, NVIDIA MAKES NO REPRESENTATION ABOUT THE 
  * SUITABILITY OF THESE LICENSED DELIVERABLES FOR ANY PURPOSE.  THEY ARE 
  * PROVIDED "AS IS" WITHOUT EXPRESS OR IMPLIED WARRANTY OF ANY KIND. 
  * NVIDIA DISCLAIMS ALL WARRANTIES WITH REGARD TO THESE LICENSED 
  * DELIVERABLES, INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY, 
  * NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE. 
  * NOTWITHSTANDING ANY TERMS OR CONDITIONS TO THE CONTRARY IN THE 
  * LICENSE AGREEMENT, IN NO EVENT SHALL NVIDIA BE LIABLE FOR ANY 
  * SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, OR ANY 
  * DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, 
  * WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS 
  * ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE 
  * OF THESE LICENSED DELIVERABLES. 
  * 
  * U.S. Government End Users.  These Licensed Deliverables are a 
  * "commercial item" as that term is defined at 48 C.F.R. 2.101 (OCT 
  * 1995), consisting of "commercial computer software" and "commercial 
  * computer software documentation" as such terms are used in 48 
  * C.F.R. 12.212 (SEPT 1995) and are provided to the U.S. Government 
  * only as a commercial end item.  Consistent with 48 C.F.R.12.212 and 
  * 48 C.F.R. 227.7202-1 through 227.7202-4 (JUNE 1995), all 
  * U.S. Government End Users acquire the Licensed Deliverables with 
  * only those rights set forth herein. 
  * 
  * Any use of the Licensed Deliverables in individual and commercial 
  * software must include, in the user documentation and internal 
  * comments to the code, the above Disclaimer and U.S. Government End 
  * Users Notice. 
  */ 
#ifndef NV_NPPS_H
#define NV_NPPS_H
 
/**
 * \file npps.h
 * NPP Signal Processing Functionality.
 */
 
#if (defined(_WIN32) || defined(_WIN64))
#if !defined NPP_EXTERN_C
#define NPP_EXTERN_C extern "C++"
#endif
#if !defined NPP_DECLSPEC
#define NPP_DECLSPEC __declspec(dllexport)
#endif
#else /* (defined(_WIN32) || defined(_WIN64)) */
#if !defined NPP_EXTERN_C
#define NPP_EXTERN_C  extern "C"
#endif
#define NPP_DECLSPEC
#endif /* (defined(_WIN32) || defined(_WIN64)) */

#include "nppdefs.h"

#ifdef __cplusplus
#ifdef NPP_PLUS
using namespace nppPlusV;
#else
NPP_EXTERN_C {
#endif
#endif

/** @defgroup npps NPP Signal Processing
 * The set of signal processing functions available in the library.
 * @{
 *
 */

#ifdef NPP_PLUS

#include "nppPlus/nppsPlus_support_functions.h"
#include "nppPlus/nppsPlus_initialization.h"
#include "nppPlus/nppsPlus_conversion_functions.h"
#include "nppPlus/nppsPlus_arithmetic_and_logical_operations.h"
#include "nppPlus/nppsPlus_statistics_functions.h"
#include "nppPlus/nppsPlus_filtering_functions.h"

#else

#include "npps_support_functions.h"
#include "npps_initialization.h"
#include "npps_conversion_functions.h"
#include "npps_arithmetic_and_logical_operations.h"
#include "npps_statistics_functions.h"
#include "npps_filtering_functions.h"

#endif

/** @} end of Signal Processing module */
 
#ifdef __cplusplus
#ifndef NPP_PLUS
} /* extern "C" */
#endif
#endif

#endif /* NV_NPPS_H */
